import { 
    SafeAreaView,
    View,
    Image,
    Text,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    ScrollView
 } from "react-native"
import login_image from '../assets/images/login_group.png';
import login_page_1 from '../assets/images/loginpage1.png';
import login_page_2 from '../assets/images/loginpage2.png';
import login_page_3 from '../assets/images/loginpage3.png';
import login_page_4 from '../assets/images/loginpage4.png';
import login_page_5 from '../assets/images/loginpage5.png';
import login_page_6 from '../assets/images/loginpage6.png';



export const Login = ({navigation}:any) => {

    const press_forgot_password = () => {
        navigation.navigate('ForgotPassword');
    }

    const onpress_login = () => {
        navigation.navigate('Navigate_Home');
    }

    return (

        <SafeAreaView style={Styles.main}>

            
                <View style={{position:'relative'}}>

                    <View style={{height: 274, width: 263, alignSelf: 'center'}}>
                        <Image source={login_image}/>
                    </View> 

                    <View style={{width: 43, height: 43, left: "67%", top:"-30%"}}>
                        <Image source={login_page_1}/>
                    </View>

                    <View style={{width: 29, height: 29, right:"8%", bottom: "20%", top: "-20%"}}>
                        <Image source={login_page_2}/>
                    </View>

                    <View style={{width: 26, height: 25, position: 'absolute', top: "24%", left: "-12%"}}>
                        <Image source={login_page_3}/>
                    </View>

                    <View style={{width: 26, height: 25, top:"-73%", left: "65%"}}>
                        <Image source={login_page_4}/>
                    </View>

                    <View style={{width: 43, height: 43, left: "60%", top:"-28%"}}>
                        <Image source={login_page_5}/>
                    </View>

                    <View style={{width: 43, height: 43, left: "68%", top: "-20%"}}>
                        <Image source={login_page_6}/>
                    </View>

                </View>

                <View style={{marginTop: "-35%"}}>
                    <Text style={{textAlign: 'center', fontSize: 36, color: '#171C15', fontFamily: 'Nunito', fontWeight: '700'}}>
                        Login Now
                    </Text>

                    <Text style={{color: '#989898', textAlign: 'center', fontFamily: 'Montserrat', fontSize: 16, fontStyle: 'normal', fontWeight: '500', marginTop: "3%", marginBottom: "5%"}}>
                        Please enter the detail below to contiue.
                    </Text>

                    <View style={Styles.input}>
                        <TextInput style={Styles.placeholder} placeholder="Email"/>
                    </View>
                    
                    <View style={Styles.input}>
                        <TextInput style={Styles.placeholder} placeholder="Password"/>
                    </View>

                    <View>
                        <TouchableOpacity onPress={onpress_login}>
                            <Text style={Styles.login_button}>LOG IN</Text>
                        </TouchableOpacity>
                    </View>

                    <View style={{marginTop: "2%"}}>
                        <TouchableOpacity onPress={press_forgot_password}>
                            <Text style={{textAlign: 'center', color: '#171C15', fontSize: 14, fontWeight: '400', fontStyle:'normal', textDecorationLine: "underline"}}>
                                Forgot Password?
                            </Text>
                        </TouchableOpacity>
                    </View>
                </View>
            
        </SafeAreaView>
    )
}



const Styles = StyleSheet.create ({
    main: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'white',
        height: "100%"
    }, 
    input:{
        marginTop: "3%",
        borderWidth: 0.8, 
        borderColor: 'white', 
        borderRadius: 10, 
        backgroundColor: '#F9F9F9', 
        width: 388
    }, 
    placeholder:{
        color: 'black', 
        fontFamily: 'Montserrat', 
        fontSize: 16, 
        fontWeight: '500',
        marginLeft: 20
    },
    login_button:{
        marginTop: 30,
        textAlign:'center', 
        justifyContent:'center', 
        alignItems:'center', 
        backgroundColor:'#388847', 
        borderRadius:18, 
        paddingTop: 18, 
        paddingBottom: 18, 
        paddingRight: 165, 
        paddingLeft: 165, 
        color: 'white', 
        fontFamily: 'Montserrat',
        fontWeight: '500',
        fontStyle: 'normal',
        fontSize: 16,
    }

})